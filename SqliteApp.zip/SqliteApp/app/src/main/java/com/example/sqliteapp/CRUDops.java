package com.example.sqliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class CRUDops {
    private final DatabaseHelper databaseHelper;
    public CRUDops(Context context){
        databaseHelper= new DatabaseHelper(context);
    }
    public long addContact(String name,String email){
        SQLiteDatabase db=databaseHelper.getWritableDatabase();
        ContentValues sv=new ContentValues();
        sv.put("name",name);
        sv.put("email",email);
        long id= db.insert("items",null,sv);
        db.close();
        return id;
    }
    public Cursor getAllContacts(){
        SQLiteDatabase db=databaseHelper.getReadableDatabase();
        return db.query("items",null,null,null,null,null,null);

    }
    public void updateContact(int id,String name,String email){
        SQLiteDatabase db=databaseHelper.getWritableDatabase();
        ContentValues sv=new ContentValues();
        sv.put("name",name);
        sv.put("email",email);
        db.update("items",sv,"id=?",new String[]{String.valueOf(id)});
        db.close();
    }
    public void deleteContact(int id) {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        db.delete("items", "id=?", new String[]{String.valueOf(id)});
        db.close();
    }
}
